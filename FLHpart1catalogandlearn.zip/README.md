# FLH Learning Library

The consolidated home of the Vanderbilt Staff Learning Collection: every
course, every edition (classroom, self-paced, facilitator), the printable
syllabi, and the catalog, as one static site behind one URL.

- `index.html` — the catalog
- `index-of-pages.html` — every page in the collection with its path
- `learn/` — Working Smarter and the Faster series
- `courses/`, `ai-coaching-feedback/`, `ai-talent-decisions/`,
  `leading-ai-adoption/` — all other courses
- `tools/` — generators for the syllabi and the page index

All internal links are relative, so the site works at any domain or under
a path prefix (e.g. /FLH/). QR codes and printed URLs resolve from the
domain the site is served on. Deploy by pointing a Vercel project (or any
static host) at the repo root; no build step.
